package com.clase.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicacionesApplication.class, args);
	}

}
